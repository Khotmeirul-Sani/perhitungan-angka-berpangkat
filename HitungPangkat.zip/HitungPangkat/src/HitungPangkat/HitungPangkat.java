package HitungPangkat;

import java.util.Scanner;

/**
*
* @author SanSan
*/

public class HitungPangkat 
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       double nilai,pangkat,nilai2;
       System.out.println("Selamat Datang");
       Scanner masukan = new Scanner (System.in);
       System.out.println("Masukkan Nilai:");
       nilai=masukan.nextDouble();
       System.out.println("Masukan Pangkatnya:");
       pangkat = masukan.nextDouble();
       
       nilai2=Math.pow(nilai, pangkat);
       System.out.println("Hasil Pangkatnya:"+nilai2);
       System.out.println("Program Telah Selesai Di Operasikan");
	}
}